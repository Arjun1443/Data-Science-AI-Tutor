
import React, { useState, useCallback } from 'react';
import Header from './components/Header';
import TopicSelector from './components/TopicSelector';
import LearningView from './components/LearningView';
import { DATA_SCIENCE_TOPICS } from './constants';

const App: React.FC = () => {
  const [selectedTopic, setSelectedTopic] = useState<string | null>(null);

  const handleTopicSelect = useCallback((topic: string) => {
    setSelectedTopic(topic);
  }, []);

  const handleBack = useCallback(() => {
    setSelectedTopic(null);
  }, []);

  return (
    <div className="min-h-screen bg-primary font-sans">
      <Header />
      <main className="container mx-auto p-4 md:p-8">
        {selectedTopic ? (
          <LearningView topic={selectedTopic} onBack={handleBack} />
        ) : (
          <TopicSelector topics={DATA_SCIENCE_TOPICS} onTopicSelect={handleTopicSelect} />
        )}
      </main>
      <footer className="text-center p-4 text-text-muted text-sm">
        <p>Built with Gemini AI. For educational purposes only.</p>
      </footer>
    </div>
  );
};

export default App;
