
export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
}

export interface Topic {
  title: string;
  description: string;
}
