
import React from 'react';
import ConceptExplainer from './ConceptExplainer';
import ChatAssistant from './ChatAssistant';

interface LearningViewProps {
  topic: string;
  onBack: () => void;
}

const ArrowLeftIcon: React.FC<{className?: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
    </svg>
);


const LearningView: React.FC<LearningViewProps> = ({ topic, onBack }) => {
  return (
    <div className="animate-fade-in">
        <button 
            onClick={onBack} 
            className="flex items-center space-x-2 text-text-secondary hover:text-accent transition-colors duration-200 mb-6 group"
        >
            <ArrowLeftIcon className="w-5 h-5 transform group-hover:-translate-x-1 transition-transform duration-200" />
            <span>Back to Topics</span>
        </button>
        <div className="flex flex-col lg:flex-row lg:space-x-8">
            <div className="lg:w-1/2 w-full mb-8 lg:mb-0">
                <ConceptExplainer topic={topic} />
            </div>
            <div className="lg:w-1/2 w-full">
                <ChatAssistant topic={topic} />
            </div>
        </div>
    </div>
  );
};

export default LearningView;
