
import React, { useState, useEffect, useRef, FormEvent, useCallback } from 'react';
import { Chat } from '@google/genai';
import { ChatMessage } from '../types';
import { startChat, sendMessageStream } from '../services/geminiService';

interface ChatAssistantProps {
    topic: string;
}

const SendIcon: React.FC<{className?: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="currentColor">
        <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>
    </svg>
);

const ChatAssistant: React.FC<ChatAssistantProps> = ({ topic }) => {
    const [chat, setChat] = useState<Chat | null>(null);
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [userInput, setUserInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const chatContainerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const newChat = startChat(topic);
        setChat(newChat);
        setMessages([
            {
                id: 'init',
                role: 'model',
                text: `Hi! I'm your AI tutor. Ask me anything about ${topic}.`,
            },
        ]);
    }, [topic]);

    useEffect(() => {
        if (chatContainerRef.current) {
            chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
        }
    }, [messages]);
    
    const handleSendMessage = useCallback(async (e: FormEvent) => {
        e.preventDefault();
        if (!userInput.trim() || !chat || isLoading) return;

        const userMessage: ChatMessage = {
            id: Date.now().toString(),
            role: 'user',
            text: userInput,
        };
        
        setMessages(prev => [...prev, userMessage]);
        setUserInput('');
        setIsLoading(true);
        
        const modelMessageId = (Date.now() + 1).toString();
        setMessages(prev => [...prev, { id: modelMessageId, role: 'model', text: '' }]);

        await sendMessageStream(chat, userInput, (chunk) => {
            setMessages(prev =>
                prev.map(msg =>
                    msg.id === modelMessageId ? { ...msg, text: msg.text + chunk } : msg
                )
            );
        });

        setIsLoading(false);

    }, [userInput, chat, isLoading]);

    return (
        <div className="bg-secondary rounded-lg shadow-lg flex flex-col h-[70vh] max-h-[800px]">
            <div className="p-4 border-b border-text-muted/20">
                <h3 className="text-xl font-bold text-center text-text-secondary">AI Chat Assistant</h3>
            </div>
            <div ref={chatContainerRef} className="flex-1 p-4 overflow-y-auto space-y-4">
                {messages.map((message) => (
                    <div key={message.id} className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-xs md:max-w-md lg:max-w-lg px-4 py-2 rounded-2xl ${
                            message.role === 'user' 
                            ? 'bg-accent text-white rounded-br-none' 
                            : 'bg-primary text-text-primary rounded-bl-none'
                        }`}>
                            <p className="whitespace-pre-wrap">{message.text || '...'}</p>
                        </div>
                    </div>
                ))}
                {isLoading && messages[messages.length - 1]?.role === 'model' && (
                    <div className="flex justify-start">
                         <div className="max-w-xs md:max-w-md lg:max-w-lg px-4 py-2 rounded-2xl bg-primary text-text-primary rounded-bl-none">
                            <div className="flex items-center space-x-2">
                                <span className="h-2 w-2 bg-accent rounded-full animate-pulse [animation-delay:-0.3s]"></span>
                                <span className="h-2 w-2 bg-accent rounded-full animate-pulse [animation-delay:-0.15s]"></span>
                                <span className="h-2 w-2 bg-accent rounded-full animate-pulse"></span>
                            </div>
                        </div>
                    </div>
                )}
            </div>
            <div className="p-4 border-t border-text-muted/20">
                <form onSubmit={handleSendMessage} className="flex items-center space-x-2">
                    <input
                        type="text"
                        value={userInput}
                        onChange={(e) => setUserInput(e.target.value)}
                        placeholder="Ask a follow-up question..."
                        className="flex-1 bg-primary border border-text-muted/30 rounded-full py-2 px-4 focus:outline-none focus:ring-2 focus:ring-accent text-text-primary transition-all duration-200"
                        disabled={isLoading}
                    />
                    <button
                        type="submit"
                        disabled={isLoading || !userInput.trim()}
                        className="bg-accent hover:bg-accent-hover text-white rounded-full p-3 disabled:bg-text-muted disabled:cursor-not-allowed transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-accent-hover"
                    >
                        <SendIcon className="w-5 h-5" />
                    </button>
                </form>
            </div>
        </div>
    );
};

export default ChatAssistant;
