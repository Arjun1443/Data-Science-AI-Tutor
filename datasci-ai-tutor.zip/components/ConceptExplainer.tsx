
import React, { useState, useEffect } from 'react';
import { explainConcept } from '../services/geminiService';

interface ConceptExplainerProps {
  topic: string;
}

const LoadingSkeleton: React.FC = () => (
  <div className="space-y-6">
    <div className="h-8 bg-secondary/50 rounded-md w-3/4 animate-pulse-fast"></div>
    <div className="space-y-3">
      <div className="h-4 bg-secondary/50 rounded-md w-full animate-pulse-fast"></div>
      <div className="h-4 bg-secondary/50 rounded-md w-5/6 animate-pulse-fast"></div>
      <div className="h-4 bg-secondary/50 rounded-md w-full animate-pulse-fast"></div>
    </div>
    <div className="h-6 bg-secondary/50 rounded-md w-1/2 animate-pulse-fast"></div>
    <div className="space-y-3">
      <div className="h-4 bg-secondary/50 rounded-md w-full animate-pulse-fast"></div>
      <div className="h-4 bg-secondary/50 rounded-md w-full animate-pulse-fast"></div>
    </div>
  </div>
);


const ConceptExplainer: React.FC<ConceptExplainerProps> = ({ topic }) => {
  const [explanation, setExplanation] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchExplanation = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const result = await explainConcept(topic);
        setExplanation(result);
      } catch (err) {
        setError('Failed to load explanation. Please try again.');
        console.error(err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchExplanation();
  }, [topic]);

  return (
    <div className="bg-secondary p-6 rounded-lg shadow-lg h-full">
      <h2 className="text-3xl font-bold mb-4 text-text-secondary">{topic}</h2>
      <div className="text-text-primary/90 leading-relaxed whitespace-pre-wrap font-mono">
        {isLoading ? (
          <LoadingSkeleton />
        ) : error ? (
          <p className="text-red-400">{error}</p>
        ) : (
          explanation
        )}
      </div>
    </div>
  );
};

export default ConceptExplainer;
