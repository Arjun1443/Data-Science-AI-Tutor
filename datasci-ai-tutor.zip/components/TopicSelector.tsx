
import React from 'react';
import { Topic } from '../types';

interface TopicSelectorProps {
  topics: Topic[];
  onTopicSelect: (topicTitle: string) => void;
}

const TopicCard: React.FC<{ topic: Topic; onClick: () => void }> = ({ topic, onClick }) => (
    <button
      onClick={onClick}
      className="bg-secondary p-6 rounded-lg shadow-lg hover:shadow-accent/30 transform hover:-translate-y-1 transition-all duration-300 ease-in-out text-left w-full focus:outline-none focus:ring-2 focus:ring-accent"
    >
      <h3 className="text-xl font-bold text-text-secondary">{topic.title}</h3>
      <p className="mt-2 text-text-muted">{topic.description}</p>
    </button>
);


const TopicSelector: React.FC<TopicSelectorProps> = ({ topics, onTopicSelect }) => {
  return (
    <section className="animate-fade-in">
      <div className="text-center mb-12">
        <h2 className="text-4xl font-extrabold mb-2 bg-clip-text text-transparent bg-gradient-to-r from-text-secondary to-accent">
          Welcome to Your AI Data Science Tutor
        </h2>
        <p className="text-lg text-text-muted max-w-2xl mx-auto">
          Select a topic to begin your learning journey. Our AI will provide a comprehensive explanation and answer your questions.
        </p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {topics.map((topic) => (
          <TopicCard key={topic.title} topic={topic} onClick={() => onTopicSelect(topic.title)} />
        ))}
      </div>
    </section>
  );
};

export default TopicSelector;
