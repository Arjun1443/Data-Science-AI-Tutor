
import { GoogleGenAI, Chat, GenerateContentResponse } from "@google/genai";
import { ChatMessage } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const explainConcept = async (topic: string): Promise<string> => {
  try {
    const prompt = `
      You are an expert data science educator. Explain the concept of "${topic}" in a clear, concise, and engaging way.
      Structure your explanation with the following sections:
      1.  **Introduction:** A simple, one-paragraph overview of what it is and why it's important.
      2.  **Core Idea:** Explain the fundamental mechanism or idea behind the concept in simple terms. Use an analogy if helpful.
      3.  **Key Steps / Components:** List and briefly explain the main steps or components involved.
      4.  **Common Use Cases:** Provide 3-4 bullet points of real-world applications.
      5.  **Pros and Cons:** Briefly list 2-3 advantages and disadvantages.

      Keep the language accessible to a beginner but technically accurate. Do not use markdown, just plain text with clear headings and spacing.
    `;
    const response: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Error explaining concept:", error);
    return "Sorry, I couldn't generate an explanation for this topic. Please try again later.";
  }
};


export const startChat = (topic: string): Chat => {
    const chat: Chat = ai.chats.create({
        model: 'gemini-2.5-flash',
        config: {
          systemInstruction: `You are a friendly and helpful Data Science AI Tutor. Your current focus is on "${topic}". Answer the user's questions clearly and provide simple code examples in Python when asked. Be encouraging and supportive.`,
        },
    });
    return chat;
};

export const sendMessageStream = async (
    chat: Chat, 
    message: string, 
    onChunk: (chunk: string) => void
): Promise<void> => {
    try {
        const result = await chat.sendMessageStream({ message });
        for await (const chunk of result) {
            onChunk(chunk.text);
        }
    } catch (error) {
        console.error("Error sending message:", error);
        onChunk("An error occurred. Please try sending your message again.");
    }
};
