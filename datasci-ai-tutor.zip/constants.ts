
import { Topic } from './types';

export const DATA_SCIENCE_TOPICS: Topic[] = [
  { title: 'Linear Regression', description: 'Predicting continuous values based on linear relationships.' },
  { title: 'Logistic Regression', description: 'Classification algorithm for binary outcomes.' },
  { title: 'Decision Trees', description: 'Tree-like model of decisions and their possible consequences.' },
  { title: 'Random Forest', description: 'Ensemble learning method using multiple decision trees.' },
  { title: 'Support Vector Machines', description: 'Powerful classification algorithm finding an optimal hyperplane.' },
  { title: 'K-Means Clustering', description: 'Unsupervised learning to partition data into K clusters.' },
  { title: 'Principal Component Analysis', description: 'Dimensionality-reduction technique to transform data.' },
  { title: 'Neural Networks', description: 'Computing systems inspired by the biological neural networks.' },
  { title: 'Natural Language Processing', description: 'Enabling computers to understand and process human language.' },
  { title: 'Data Cleaning', description: 'Process of detecting and correcting corrupt or inaccurate records.' },
  { title: 'Feature Engineering', description: 'Using domain knowledge to create features for ML algorithms.' },
  { title: 'SQL for Data Science', description: 'Querying and managing data in relational databases.' },
];
